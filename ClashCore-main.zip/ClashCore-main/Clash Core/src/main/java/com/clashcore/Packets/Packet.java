package Packets.Factory;

import Logic.Device;

public interface Packet {
    void decode();
    void process();
}
