![O](https://img.shields.io/badge/Java-Black?style=for-the-badge&logo=OpenJdk&logoColor=White&color=FF8000) ![J](https://img.shields.io/badge/11%2B-Black?style=for-the-badge&logoColor=White&label=Jdk&color=FF8000) ![C](https://img.shields.io/badge/Core-Black?style=for-the-badge&logoColor=White&label=Clash&color=FF8000)


The core of the Clash of Clans server development is based on Java. Works from all versions!
![Screenshot](https://i.imgur.com/CXqsMPg.png) 
### Need help?
Contact me via  
[Telegram](https://t.me/MEMozki)
### IMPORTANT
This content is not affiliated, approved, sponsored or approved specifically by Supercell and Supercell is not responsible for it. For more, see the Supercell Fan Content Policy: www.supercell.com/fan-content-policy
