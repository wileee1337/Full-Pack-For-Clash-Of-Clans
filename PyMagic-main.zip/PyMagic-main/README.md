# What? 
The most adequate server for clash of clans 5.2.4
