from Protocol.TcpNetwork import TcpNetwork

TcpNetwork(("0.0.0.0", 9339))